# Broadcast player craft globally
title @a title {"text":"THE SWORD OF DEATH HAS BEEN FORMED","color":"red","bold":true}
execute as @s run title @a subtitle {"text":"","extra":[{"text":"Crafted by "},{"selector":"@s","color":"yellow"}]}
tellraw @a {"text":"THE SWORD OF DEATH HAS BEEN FORMED","color":"red"}
tellraw @a {"text":"","extra":[{"text":"Crafted by "},{"selector":"@s","color":"yellow"}]}
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 1 0.5