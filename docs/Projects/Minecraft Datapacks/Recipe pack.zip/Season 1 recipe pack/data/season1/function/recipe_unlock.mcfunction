# 1. Reveal the secret recipe to all players globally
recipe give @a season1:mystery_blade
recipe give @a season1:battle_axe
recipe give @a season1:kadak_shirt
recipe give @a season1:fire_axe


# 2. Server-wide frantic broadcast
title @a title {"text":"A SECRET RECIPE UNLOCKED","color":"dark_red","bold":true}
title @a subtitle {"text":"Check your crafting book. 24 Hours remain.","color":"gold"}
playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 1 0.1

# 3. Enable recipe auto-unlock for anyone who logs in late during the buffer day
datapack enable "file/season1"