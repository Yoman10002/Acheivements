# 1. Give potion effects while wearing
execute as @a if items entity @s armor.chest *[minecraft:custom_data~{blood_protector:1b}] run effect give @s minecraft:strength 2 0 true
execute as @a if items entity @s armor.chest *[minecraft:custom_data~{blood_protector:1b}] run effect give @s minecraft:speed 2 0 true

# 2. Tag current wearers
execute as @a if items entity @s armor.chest *[minecraft:custom_data~{blood_protector:1b}] run tag @s add wearing_protector

# 3. Clear effects immediately when unequipped
execute as @a[tag=wearing_protector] unless items entity @s armor.chest *[minecraft:custom_data~{blood_protector:1b}] run effect clear @s minecraft:strength
execute as @a[tag=wearing_protector] unless items entity @s armor.chest *[minecraft:custom_data~{blood_protector:1b}] run effect clear @s minecraft:speed

# 4. REMOVE TAG LAST (This must be the final command block/line)
execute as @a[tag=wearing_protector] unless items entity @s armor.chest *[minecraft:custom_data~{blood_protector:1b}] run tag @s remove wearing_protector

effect give @a[nbt={ArmorItems:[{},{},{tag:{custom_data:{sunforged_aegis:1b}}},{}]}] minecraft:regeneration 2 0 true