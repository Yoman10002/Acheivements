tellraw @a {"text":"[Season 1 Finale Datapack Loaded]","color":"green"}

scoreboard objectives add bd_tp_timer dummy

# Create team with PvP disabled
team add end_pvp_off "No End PvP"
team modify end_pvp_off friendlyFire false

scoreboard objectives add has_joined dummy
scoreboard objectives add left_game custom:leave_game
scoreboard objectives add spawn_prot dummy