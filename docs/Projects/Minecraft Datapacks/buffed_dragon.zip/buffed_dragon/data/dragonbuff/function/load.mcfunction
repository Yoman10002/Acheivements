scoreboard objectives add bd_timer dummy
scoreboard objectives add bd_chatter dummy
scoreboard objectives add bd_hp dummy
scoreboard objectives add bd_p2timer dummy
scoreboard objectives add bd_stream dummy
scoreboard objectives add bd_striketimer dummy
scoreboard objectives add bd_novatimer dummy