tag @s add caged

# 1. Clear out any old/messy iron bars in a 5x5x5 box around the crystal
execute at @s run fill ~-2 ~-1 ~-2 ~2 ~3 ~2 minecraft:air replace minecraft:iron_bars

# 2. Convert top layer of the obsidian pillar into Crying Obsidian
execute at @s run fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 minecraft:crying_obsidian replace minecraft:obsidian
execute at @s run fill ~-2 ~-2 ~-2 ~2 ~-5 ~2 minecraft:crying_obsidian replace minecraft:obsidian

# 3. Build a precise Vanilla-style 3x3x3 Iron Cage (Hollow inside)
execute at @s run fill ~-3 ~-2 ~-3 ~3 ~4 ~3 minecraft:iron_bars outline
execute at @s run fill ~0 ~0 ~0 ~0 ~2 ~0 minecraft:air