tag @s add phase2_active

# Announcement & Visual Effects
tellraw @a {"text":"<Ender Dragon> YOU WILL NOT LEAVE THIS REALM ALIVE! (PHASE 2)","color":"red","bold":true}
effect give @a[distance=..150] minecraft:blindness 5 1 true
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 10 0.2

# Clear any remaining minions and instantly spawn 5 enraged Phantoms
kill @e[type=phantom,tag=dragon_minion]
summon phantom ~ ~20 ~ {Size:3,Tags:["dragon_minion"]}
summon phantom ~ ~20 ~ {Size:2,Tags:["dragon_minion"]}
summon phantom ~ ~20 ~ {Size:2,Tags:["dragon_minion"]}