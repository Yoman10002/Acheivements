# 1. Buff HP (Set to 500 HP)
execute as @e[type=ender_dragon,tag=!buffed] run attribute @s max_health base set 500
execute as @e[type=ender_dragon,tag=!buffed] run data merge entity @s {Health:500f}
execute as @e[type=ender_dragon,tag=!buffed] run tag @s add buffed

# 2. Setup Crystals
execute as @e[type=end_crystal,tag=!caged] at @s run function dragonbuff:crystal

# 3. Track Dragon HP & Trigger Phase 2 at <= 250 HP
execute as @e[type=ender_dragon] store result score @s bd_hp run data get entity @s Health
execute as @e[type=ender_dragon,tag=!phase2_active] if score @s bd_hp matches ..250 at @s run function dragonbuff:phase2

# 3.5 Phase 2 Fireball Volley (Only fires when FLYING, not perching)
execute as @e[type=ender_dragon,tag=phase2_active] unless entity @s[nbt={DragonPhase:3}] unless entity @s[nbt={DragonPhase:4}] run scoreboard players add #p2fireball bd_p2timer 1
execute if score #p2fireball bd_p2timer matches 400.. at @e[type=ender_dragon,tag=phase2_active] run function dragonbuff:fireball_burst
execute if score #p2fireball bd_p2timer matches 400.. run scoreboard players set #p2fireball bd_p2timer 0

# 3.6 Fireball Stream Logic (Executes AT the Ender Dragon)
execute if score #stream_count bd_stream matches 1.. run scoreboard players add #stream_delay bd_stream 1
execute if score #stream_delay bd_stream matches 4.. at @e[type=ender_dragon] run function dragonbuff:fireball_single
execute if score #stream_delay bd_stream matches 4.. run scoreboard players remove #stream_count bd_stream 1
execute if score #stream_delay bd_stream matches 4.. run scoreboard players set #stream_delay bd_stream 0

# Attack 2: Lightning Tempest (Every 25s / 500 ticks)
execute as @e[type=ender_dragon,tag=phase2_active] run scoreboard players add #strike bd_striketimer 1
execute if score #strike bd_striketimer matches 500.. at @e[type=ender_dragon,tag=phase2_active] run function dragonbuff:lightning_tempest
execute if score #strike bd_striketimer matches 500.. run scoreboard players set #strike bd_striketimer 0

# Attack 3: Crystal Overload / Ender Nova (1500 ticks)
execute as @e[type=ender_dragon,tag=phase2_active] run scoreboard players add #nova bd_novatimer 1
execute if score #nova bd_novatimer matches 2800.. at @e[type=ender_dragon,tag=phase2_active] run function dragonbuff:crystal_overload
execute if score #nova bd_novatimer matches 2800.. run scoreboard players set #nova bd_novatimer 0

# Active Dark Crystal Beam Processing
execute as @e[type=end_crystal,tag=dark_crystal] at @s run function dragonbuff:dark_crystal_tick

# 4. Spawns 5 Phantoms every 30s (600 ticks)
execute if entity @e[type=ender_dragon] run scoreboard players add #phantom bd_timer 1
execute if score #phantom bd_timer matches 900.. at @e[type=ender_dragon] run summon phantom ~ ~20 ~ {Size:3,Tags:["dragon_minion"],CustomName:"Dragon Minion"}
execute if score #phantom bd_timer matches 900.. at @e[type=ender_dragon] run summon phantom ~ ~20 ~ {Size:2,Tags:["dragon_minion"],CustomName:"Dragon Minion"}
execute if score #phantom bd_timer matches 900.. at @e[type=ender_dragon] run summon phantom ~ ~20 ~ {Size:1,Tags:["dragon_minion"],CustomName:"Dragon Minion"}
execute if score #phantom bd_timer matches 900.. at @e[type=ender_dragon] run summon phantom ~ ~20 ~ {Size:3,Tags:["dragon_minion"],CustomName:"Dragon Minion"}
execute if score #phantom bd_timer matches 900.. at @e[type=ender_dragon] run summon phantom ~ ~20 ~ {Size:2,Tags:["dragon_minion"],CustomName:"Dragon Minion"}
execute if score #phantom bd_timer matches 900.. at @e[type=ender_dragon] run summon phantom ~ ~20 ~ {Size:1,Tags:["dragon_minion"],CustomName:"Dragon Minion"}
execute if score #phantom bd_timer matches 900.. run scoreboard players set #phantom bd_timer 0

# 5. Perching Detection
execute as @e[type=ender_dragon,tag=!perching] if entity @s[nbt={DragonPhase:3}] run function dragonbuff:perch
execute as @e[type=ender_dragon,tag=perching] unless entity @s[nbt={DragonPhase:3}] run tag @s remove perching

# 6. Fireballs
execute as @e[type=dragon_fireball,tag=!processed] run tellraw @a {"text":"<Ender Dragon> Face my wrath!","color":"dark_red","bold":true}
execute as @e[type=dragon_fireball,tag=!processed] run tag @s add processed

# 7. Explosive damage cloud
execute in minecraft:the_end as @e[type=area_effect_cloud,tag=!burst] at @s run function dragonbuff:explosion

# 8. Random Chatter
execute if entity @e[type=ender_dragon] run scoreboard players add #chatter bd_chatter 1
execute if score #chatter bd_chatter matches 1000.. run tellraw @a {"text":"<Ender Dragon> Many have come and gone, you think you can defeat me?","color":"dark_purple"}
execute if score #chatter bd_chatter matches 1000.. run scoreboard players set #chatter bd_chatter 0




# Active Dark Crystal Processing (Heals Dragon & Blasts Players)
execute as @e[type=end_crystal,tag=dark_crystal] at @s run function dragonbuff:dark_crystal_tick