tag @s add burst
particle minecraft:explosion_emitter ~ ~ ~ 1 1 1 0 1 normal
playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 3 1.2

# Reduced damage per fireball to keep the stream balanced (6 damage = 3 hearts)
execute as @a[distance=..5] run damage @s 6 minecraft:explosion
kill @s