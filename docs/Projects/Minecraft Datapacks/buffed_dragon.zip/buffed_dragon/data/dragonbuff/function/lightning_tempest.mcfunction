tellraw @a [{"text":"<Ender Dragon> ","color":"dark_purple"},{"text":"THE SKY RAINS THUNDER! RUN!","color":"yellow","bold":true}]
playsound minecraft:entity.lightning_bolt.thunder hostile @a ~ ~ ~ 10 0.8

# Strike lightning and set the floor on fire under every player in the End
execute in minecraft:the_end as @a[gamemode=!spectator] at @s run summon lightning_bolt ~ ~ ~
execute in minecraft:the_end as @a[gamemode=!spectator] at @s run setblock ~ ~ ~ minecraft:fire replace minecraft:air