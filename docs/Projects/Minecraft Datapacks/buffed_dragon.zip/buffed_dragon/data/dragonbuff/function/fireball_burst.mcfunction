playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 10 1.5
tellraw @a {"text":"<Ender Dragon> BURN TO ASHES!","color":"red","bold":true}

# Summon fireballs with active Motion vectors so they fly downward toward the ground
summon dragon_fireball ~ ~-2 ~ {Motion:[0.0,-1.2,0.0],Tags:["processed"]}
summon dragon_fireball ~2 ~-2 ~ {Motion:[0.5,-1.0,0.0],Tags:["processed"]}
summon dragon_fireball ~-2 ~-2 ~ {Motion:[-0.5,-1.0,0.0],Tags:["processed"]}
summon dragon_fireball ~ ~-2 ~2 {Motion:[0.0,-1.0,0.5],Tags:["processed"]}
summon dragon_fireball ~ ~-2 ~-2 {Motion:[0.0,-1.0,-0.5],Tags:["processed"]}