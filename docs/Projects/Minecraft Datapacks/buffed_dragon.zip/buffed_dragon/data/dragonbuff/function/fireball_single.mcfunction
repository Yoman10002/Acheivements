playsound minecraft:entity.ender_dragon.shoots hostile @a ~ ~ ~ 2 1.2

# Targets the nearest player's position
execute at @s positioned ~ ~-2 ~ run summon dragon_fireball ~ ~ ~ {power:[0.0d,-0.4d,0.0d],item:{id:"minecraft:dragon_fireball"},Tags:["processed"]}
execute at @s as @e[type=dragon_fireball,tag=!processed_dir,limit=1,sort=nearest] run tag @s add processed_dir