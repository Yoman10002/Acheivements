tag @s add perching
tellraw @a {"text":"<Ender Dragon> I'm not like before...","color":"dark_purple","bold":true}
# Blinds everyone within 150 blocks for 8 seconds
effect give @a[distance=..150] minecraft:blindness 8 1 true
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 10 0.5