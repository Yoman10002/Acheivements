tellraw @a [{"text":"<Ender Dragon> ","color":"dark_purple"},{"text":"THE DARK CRYSTAL SIPHONS MY POWER! DESTROY IT!","color":"dark_red","bold":true}]
playsound minecraft:entity.ender_eye.death hostile @a ~ ~ ~ 10 0.5

# Spawns a Dark Crystal tied directly to the central portal (0, 100, 0) for its beam
execute in minecraft:the_end at @e[type=ender_dragon,limit=1] run summon end_crystal ~ ~12 ~ {ShowBottom:true,BeamTarget:{X:0,Y:100,Z:0},CustomName:'Dark Crystal',CustomNameVisible:true,Tags:["dark_crystal"]}