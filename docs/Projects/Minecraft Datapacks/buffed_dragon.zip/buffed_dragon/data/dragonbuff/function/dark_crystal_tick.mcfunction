# 1. Visual particles and beam sound at the Dark Crystal
execute at @s run particle minecraft:dragon_breath ~ ~ ~ 0.8 0.8 0.8 0.05 30 force
execute at @s run playsound minecraft:entity.guardian.attack hostile @a ~ ~ ~ 0.8 1.5

# 2. HEAL THE DRAGON (+5 HP via Instant Health)
execute at @s run effect give @e[type=ender_dragon,limit=1] minecraft:instant_health 1 0 true
